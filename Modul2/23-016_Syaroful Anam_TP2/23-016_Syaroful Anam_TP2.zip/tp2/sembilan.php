<?php
$nama = "Syaroful Anam"; 
$score = 85;           
if ($score >= 90) {
    $grade = "A";
} elseif ($score >= 80) {
    $grade = "B";
} elseif ($score >= 70) {
    $grade = "C";
} elseif ($score >= 60) {
    $grade = "D";
} else {
    $grade = "E";
}
echo "<h2>Laporan Grade Nilai</h2>";
echo "Nama Mahasiswa: <strong>" . $nama . "</strong><br>";
echo "Nilai Mahasiswa: <strong>" . $score . "</strong><br>";
echo "Grade Mahasiswa: <strong>" . $grade . "</strong><br>";
?>