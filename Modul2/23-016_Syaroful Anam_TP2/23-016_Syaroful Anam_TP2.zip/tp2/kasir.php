<?php

session_start();
$menu = [
    1 => ['item' => 'Nasi Goreng', 'price' => 15000],
    2 => ['item' => 'Mie Ayam', 'price' => 12000],
    3 => ['item' => 'Es Teh Manis', 'price' => 5000],
    4 => ['item' => 'Air Mineral', 'price' => 3000]
];


if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {

 
    if (isset($_POST['action']) && $_POST['action'] == 'add') {
        $choice = intval($_POST['choice']);
        $quantity = intval($_POST['quantity']);

    
        if (isset($menu[$choice]) && $quantity > 0) {
            $item = $menu[$choice];
            $item['quantity'] = $quantity;
            
            $_SESSION['cart'][] = $item;
        }
    }
    
    
    if (isset($_POST['action']) && $_POST['action'] == 'checkout') {
       
        unset($_SESSION['cart']);
    }
    
   
    header("Location: kasir.php");
    exit();
}


$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    $total_price += $item['price'] * $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sistem Kasir Sederhana</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 20px auto; }
        .menu-list { list-style: none; padding: 0; }
        .cart-item { border-bottom: 1px dashed #ddd; padding: 5px 0; }
        .total { font-size: 1.5em; font-weight: bold; color: #28a745; margin-top: 15px; }
        h1 { color: #007bff; }
    </style>
</head>
<body>

    <h1>Program Sistem Kasir Sederhana</h1>

    <hr>
    
    <h2>1. Daftar Menu:</h2>
    <ul class="menu-list">
        <?php foreach ($menu as $id => $item): ?>
            <li><?php echo $id; ?>.<?php echo $item['item']; ?> (Rp <?php echo number_format($item['price']); ?>)</li>
        <?php endforeach; ?>
    </ul>

    <hr>

    <h2>2. Masukkan Pesanan:</h2>
    <form method="POST" action="kasir.php">
        <label for="choice">Masukkan Nomor Menu (1-4):</label>
        <input type="number" id="choice" name="choice" min="1" max="4" required><br><br>
        
        <label for="quantity">Masukkan Jumlah Item:</label>
        <input type="number" id="quantity" name="quantity" min="1" required><br><br>
        
        <button type="submit" name="action" value="add">Tambahkan ke Keranjang</button>
    </form>
    
    <hr>
    
    <h2>3. Isi Keranjang:</h2>
    <?php if (empty($_SESSION['cart'])): ?>
        <p>Keranjang kosong. Silakan tambahkan pesanan di atas.</p>
    <?php else: ?>
        <?php
        $item_counter = 1;
        foreach ($_SESSION['cart'] as $item): 
            $sub_total = $item['price'] * $item['quantity'];
        ?>
            <div class="cart-item">
                <?php echo $item_counter++; ?>. <?php echo $item['quantity']; ?>x **<?php echo $item['item']; ?>** = **Rp <?php echo number_format($sub_total); ?>**
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <div class="total">
        TOTAL HARGA: Rp <?php echo number_format($total_price); ?>
    </div>

    <form method="POST" action="kasir.php" style="margin-top: 20px;">
        <button type="submit" name="action" value="checkout" <?php echo empty($_SESSION['cart']) ? 'disabled' : ''; ?>>
            Selesaikan Pembayaran (Checkout)
        </button>
    </form>

</body>
</html>