<?php
$txt = "W3Schools.com";
echo "I love $txt!";
?>