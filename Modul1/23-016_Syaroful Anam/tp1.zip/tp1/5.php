<?php
$txt = "Hello world!";  // Variabel bertipe string
$x = 5;                 // Variabel bertipe integer
$y = 10.5;              // Variabel bertipe float
?>