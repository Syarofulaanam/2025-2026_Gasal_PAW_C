
<?php
$nama     = $_POST['nama'] ?? "";
$nim      = $_POST['nim'] ?? "";
$jurusan  = $_POST['jurusan'] ?? "";
$angkatan = $_POST['angkatan'] ?? "";
$alamat   = $_POST['alamat'] ?? "";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Mahasiswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            padding: 30px;
        }
        h2 {
            color: #333;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            width: 400px;
            margin-bottom: 30px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 6px;
            color: #444;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
        }
        textarea {
            resize: vertical;
            height: 80px;
        }
        button {
            background: #3498db;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 15px;
        }
        button:hover {
            background: #2980b9;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 800px;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
            font-size: 14px;
        }
        th {
            background: #3498db;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
    </style>
</head>
<body>
    <h2>Form Input Data Mahasiswa</h2>
    <form method="post">
        <label>Nama:</label>
        <input type="text" name="nama" value="<?= htmlspecialchars($nama) ?>">

        <label>NIM:</label>
        <input type="text" name="nim" value="<?= htmlspecialchars($nim) ?>">

        <label>Jurusan:</label>
        <input type="text" name="jurusan" value="<?= htmlspecialchars($jurusan) ?>">

        <label>Angkatan:</label>
        <input type="text" name="angkatan" value="<?= htmlspecialchars($angkatan) ?>">

        <label>Alamat:</label>
        <textarea name="alamat"><?= htmlspecialchars($alamat) ?></textarea>

        <button type="submit">Kirim</button>
    </form>

    <?php if (!empty($nama) || !empty($nim) || !empty($jurusan) || !empty($angkatan) || !empty($alamat)): ?>
        <h2>Data Mahasiswa</h2>
        <table>
            <tr>
                <th>Nama</th>
                <th>NIM</th>
                <th>Jurusan</th>
                <th>Angkatan</th>
                <th>Alamat</th>
            </tr>
            <tr>
                <td><?= htmlspecialchars($nama) ?></td>
                <td><?= htmlspecialchars($nim) ?></td>
                <td><?= htmlspecialchars($jurusan) ?></td>
                <td><?= htmlspecialchars($angkatan) ?></td>
                <td><?= nl2br(htmlspecialchars($alamat)) ?></td>
            </tr>
        </table>
    <?php endif; ?>
</body>
</html>
```
