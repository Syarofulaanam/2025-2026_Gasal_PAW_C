<!DOCTYPE html>
<html>
<head>
    <title>Biodata dalam Tabel</title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<?php
// Deklarasi Variabel Biodata
$nama = "Syaroful Anam";
$nim = "230411100016";
$jurusan = "Teknik Informatika";
$angkatan = 2023;
$alamat = "Jl.kapor selatan burneh bangkalan";
?>

<h3>Biodata Mahasiswa</h3>

<table>
    <tr>
        <th>Data</th>
        <th>Keterangan</th>
    </tr>
    <tr>
        <td>Nama</td>
        <td><?php echo $nama; ?></td>
    </tr>
    <tr>
        <td>NIM</td>
        <td><?php echo $nim; ?></td>
    </tr>
    <tr>
        <td>Jurusan</td>
        <td><?php echo $jurusan; ?></td>
    </tr>
    <tr>
        <td>Angkatan</td>
        <td><?php echo $angkatan; ?></td>
    </tr>
    <tr>
        <td>Alamat</td>
        <td><?php echo $alamat; ?></td>
    </tr>
</table>

</body>
</html>